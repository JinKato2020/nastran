亀裂先端のCRAC2D 局所K場モデル（MSC Nastran 2020 SP1の公開仕様に基づく教材）

crac2d_kfield_patch.bdf はSOL 101の独立した入力です。
これは先端応力の特異性を消す模型ではありません。特異場を表すCRAC2DからKを評価する仕組みを学びます。
Nastran本体での実行は未確認。実用の有限幅板の評価モデル、検証済みのベンチマークではありません。

モデル：20×20 mm、厚さ1 mm。全形CRAC2D 1個、18節点。
単位：N・mm・MPa。E=210000 MPa、nu=0.3。平面応力IPLANE=1。
外周変位を作る理論上のK_I=1000 MPa sqrt(mm)（約31.623 MPa sqrt(m)）。
G1=GRID101が先端。G2=GRID102とG10=GRID110は両方(-10,0,0)で、別IDです。
G2はtheta=+pi、G10はtheta=-piとして理論変位を計算します。
G2～G18のXY変位をSPCで指定。全節点の3456はSPC1で0拘束。
G1のXYは自由。FORCEやLOADを使わず、SPC=10で非ゼロ変位と0拘束を選びます。
PRAC2DのGAMMAとPHIは空欄で既定0.5と180度。特異性を消すため変更しません。
ADUM8の18,0,5,0,CRAC2Dは原典の固定指定です。
G11～G18は外周中間節点であり、1/4点へ移す節点ではありません。

境界変位の式（平面応力）：
mu=E/[2(1+nu)], kappa=(3-nu)/(1+nu)
A=K_I/(2mu)*sqrt(r/(2pi))
ux=A*cos(theta/2)*(kappa-cos(theta))
uy=A*sin(theta/2)*(kappa-cos(theta))
式の出典：Chen et al. (2021), Appendix A, Eq. A.1
https://eprints.whiterose.ac.uk/id/eprint/165923/1/PSbref-phasefield.pdf#page=16
論文のフェーズフィールド法をこのBDFで実装するものではありません。
8文字欄の変位は小数点以下6桁へ丸めています。nodes_and_boundary.csvは丸め前と入力値の対応表です。

F06のCRAC2D応力出力はダミー要素形式：
S1=x, S2=y（応力評価位置の要素座標）
S3=sigma_x, S4=sigma_y, S5=tau_xy
S6=K_I, S7=K_II, S8=S9=0
S1/S2は主応力ではありません。S3～S5はr=0の先端応力ではありません。
まず終了状態とFATAL、指定した外周変位、上下対称性を確認します。
S6/1000の比、S7が0に近いかを確認します。未実行なので完全一致は保証しません。
OP2出力を読む前処理・後処理ソフトのCRAC2D対応も確認します。

実際の板の解析へ広げるには全体形状・亀裂長さ・実荷重・周辺メッシュを定義し直します。
外周寸法だけを変えてもメッシュ収束試験にはなりません。
この例では亀裂進展、接触、塑性、先端半径、J積分の出力、CRAC3Dを扱いません。
原典：MSC Nastran2020SP1 QRG(PDF1250,1657–1658,2931,3156)、Static Guide(PDF169–171)、Reference Guide(PDF189–190)。

起動例：自分の環境の正規起動コマンドで nast20200 crac2d_kfield_patch.bdf
起動名はインストール環境に合わせてください。
このBDFはASCII・CRLF・BOMなし、Bulkは8文字×10欄です。CSVのカンマ区切りは確認用表で、BDFの入力形式ではありません。
