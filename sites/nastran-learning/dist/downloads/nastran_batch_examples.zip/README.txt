﻿Nastran コマンドライン・バッチの基本セット

使い方と各行の日本語解説:
https://nastran-first-steps-jp-01a1c260.botanicalelf.chatgpt.site/batch.html

これはMSC Nastran本体・ライセンス・入力モデルを含まない教材です。
初期値のYOUR_LAUNCHER.exeは仮のパスです。正規の起動用.exeの実際のパスに変更してください。
内部のanalysis.exeを直接指定する例ではありません。
初期設定はSMP=4、DMP=0、1ジョブのmemorymax予算4 GBです。
2件同時なら資源の目安は8コア、メモリ予算の合計8 GB。利用可能な環境に合わせます。

run_single.bat: バッチと同じ場所のmodel.bdfを1件実行。
run_in_order.bat: case_A\model.bdfの呼出しが戻ってからcase_B\model.bdfを実行。
run_two_parallel.bat: 同じ2件を同時起動。親バッチは待たずに戻ります。
run_worker.bat: 複数実行の共通の補助。同じ場所へ置き、親から呼びます。

編集する場所: NASTRAN、INPUT、SMP、DMP、MEMORY_GB、RUN_DIRの実行名。
複数実行は親のバッチを編集すると、その設定がworkerへ渡ります。
モデルのINCLUDE先も含めた配置を保ってください。入力はこのZIPに含みません。
ファイルは展開してから使い、CMDでそのフォルダへ移動してバッチ名を入力します。
パスの英数字・空白などに対応します。%・!などCMD特殊記号のある作業パスは扱いません。

同じ結果フォルダがあると中断します。再実行はtrial02など新しい名前に変更します。
scratch=yesは終了時にNastranのデータベースを削除する指定です。再スタート用の保存には調整が必要です。

各結果フォルダのlauncher_exit.txtは、起動コマンドが戻った後の終了コードです。
0でも解析成功の保証ではありません。model.f06、model.log、console.txtを確認し、結果の妥当性も点検します。
並列起動の親が返す0は起動要求を出せた意味で、2件の完了ではありません。
同時実行の子を監視・自動再実行・強制停止するキュー管理ツールではありません。

バッチの制御は模擬プログラムで検証しています。MSC Nastran本体・MPI・ライセンス・解析性能は未検証です。
