﻿MSC Nastran INCLUDE入門：棒1本の引張り

解説と各フィールドの表:
https://nastran-first-steps-jp-01a1c260.botanicalelf.chatgpt.site/include.html

1. ZIPを展開し、次の6ファイルをすべて同じフォルダへ置きます。
   main.bdf, mesh.inc, properties.inc, constraints.inc, load_1000.inc, load_2000.inc
2. Windows CMDでそのフォルダへcd /dで移動します。
3. 正規の起動コマンドにmain.bdfを渡します。2020 SP1での例: nast20200 "main.bdf"
   起動名は利用環境に合わせます。MSC Nastran本体とライセンスはこのZIPに含みません。
4. F06のメッセージと結果を確認します。実機ソルバーでの実行は未確認です。

親main.bdfが、形状・材料と断面・拘束・1000 Nの荷重を読み込みます。
子の.incはBulkカードだけのプレーンテキストです。SOLやBEGIN BULK、ENDDATAは入れません。
通常のBulkカードは1フィールド8文字、1行80文字です。空欄を削除したりTABに置き換えたりしません。
INCLUDE命令は別書式で、半角シングルクォート付きの短いファイル名を使っています。
全入力ファイルは半角ASCII文字・CRLF改行です。この日本語メモは入力へ貼り付けません。

ZIPのmain.bdfは1000 Nの固定例です。
2000 Nに替えるには INCLUDE 'load_1000.inc' の1行を INCLUDE 'load_2000.inc' に置き換えます。
画面で2000 Nへ変更して保存したmain.bdfでも置き換えられます。
LOAD = 20は変更不要です。両方の荷重ファイルを読むと同方向の力が合計3000 Nになります。

長さ1000 mm、面積100 mm^2、E=210000 MPa。
手計算の目安：1000 Nなら変位0.047619 mm、軸応力10 MPa、固定端X反力-1000 N。
2000 Nなら変位0.095238 mm、軸応力20 MPa、固定端X反力-2000 N。
ファイルを分けても、節点・要素・材料などのID空間は共通です。
移動や共有は親だけでなく必要な.incも含め、同名の別ファイルや.inc.txtを作らないようにします。
